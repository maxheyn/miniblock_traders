# miniblock_traders

Work in Progress

Datapack which adds special minecraft villager trades for miniblocks used to decorate.
Sample gif: https://gyazo.com/ea8c8b8214ee72e474e752e2d321a072